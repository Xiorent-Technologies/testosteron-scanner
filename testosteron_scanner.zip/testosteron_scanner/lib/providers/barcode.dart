import 'dart:convert';
import 'package:http/http.dart' as http;

class BarcodeAnalysisService {
  static const String geminiApiKey =
      'AIzaSyArppHzXPxTfI3VxedLtGHcR8OG7UgL81s'; // Replace with your actual API key
  static const String geminiBaseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
  static const String openFoodFactsBaseUrl =
      'https://world.openfoodfacts.org/api/v0/product';

  /// Extract ingredients from barcode using OpenFoodFacts API
  static Future<BarcodeProduct?> extractIngredientsFromBarcode(
      String barcode) async {
    try {
      final url = '$openFoodFactsBaseUrl/$barcode.json';
      final response = await http.get(
        Uri.parse(url),
        headers: {'User-Agent': 'Flutter-App/1.0'},
      ).timeout(Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == 1) {
          final product = data['product'];
          final productName = product['product_name'] ?? 'Unknown Product';
          final ingredientsText = product['ingredients_text'] ?? '';

          // Parse ingredients similar to Python code
          final ingredients = _parseIngredients(ingredientsText);

          return BarcodeProduct(
            productName: productName,
            ingredientsText: ingredientsText,
            ingredients: ingredients,
            barcode: barcode,
          );
        } else {
          throw Exception('Product not found');
        }
      } else {
        throw Exception('Failed to fetch product data');
      }
    } catch (e) {
      print('Error extracting ingredients: $e');
      return null;
    }
  }

  /// Parse ingredients text into a list similar to Python implementation
  static List<String> _parseIngredients(String ingredientsText) {
    if (ingredientsText.isEmpty) return [];

    return ingredientsText
        .replaceAll('.', '')
        .replaceAll(':', '')
        .replaceAll(';', ',')
        .split(',')
        .map((ingredient) => ingredient.trim().toLowerCase())
        .where((ingredient) => ingredient.isNotEmpty)
        .toList();
  }

  /// Analyze product using barcode and return structured response via Gemini
  static Future<GeminiResponse?> analyzeProductFromBarcode(String barcode,
      {String? customPrompt}) async {
    try {
      // Step 1: Get ingredients from barcode
      final barcodeProduct = await extractIngredientsFromBarcode(barcode);
      if (barcodeProduct == null) {
        print('Could not fetch product data for barcode: $barcode');
        return null;
      }

      // Step 2: Create prompt for Gemini with ingredients data
      final prompt = customPrompt ?? _createAnalysisPrompt(barcodeProduct);

      // Step 3: Send to Gemini API
      final geminiResponse = await _callGeminiApi(prompt);
      return geminiResponse;
    } catch (e) {
      print('Error analyzing product: $e');
      return null;
    }
  }

  /// Create analysis prompt for Gemini with product ingredients
  static String _createAnalysisPrompt(BarcodeProduct product) {
    return '''
    Analyze the following food product and its ingredients, then provide a response in the following JSON format:
    {
      "productName": "${product.productName}",
      "tscore": numerical_level_of_testosteron_0_to_100,
      "riskLevel": "Low Risk/Medium Risk/High Risk",
      "badIngredients": [
        {
          "name": "ingredient_name",
          "category": "Lifestyle Risk/Health Risk/Allergen/Preservative/Artificial",
          "penalty": numerical_penalty
        }
      ]
    }

    Product Details:
    - Product Name: ${product.productName}
    - Barcode: ${product.barcode}
    - Ingredients: ${product.ingredients.join(', ')}
    - Full Ingredients Text: ${product.ingredientsText}

    Please analyze each ingredient for potential health risks, considering:
    1. Artificial additives and preservatives
    2. High sodium/sugar content indicators
    3. Trans fats and unhealthy oils
    4. Common allergens
    5. Processed ingredients

    Assign a T-Score (numerical value) for testosteron level of the food or ingredients.
    Identify specific bad ingredients with their risk category and penalty points.
    Return only valid JSON.
    ''';
  }

  /// Call Gemini API with text prompt
  static Future<GeminiResponse?> _callGeminiApi(String prompt) async {
    try {
      final requestBody = {
        "contents": [
          {
            "parts": [
              {"text": prompt}
            ]
          }
        ],
        "generationConfig": {
          "temperature": 0.4,
          "topK": 32,
          "topP": 1,
          "maxOutputTokens": 4096,
        }
      };

      final response = await http.post(
        Uri.parse(geminiBaseUrl),
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': geminiApiKey,
        },
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final generatedText =
            responseData['candidates'][0]['content']['parts'][0]['text'];
        final cleanedText = _cleanResponseText(generatedText);

        try {
          final parsedResponse = jsonDecode(cleanedText);
          return GeminiResponse.fromJson(parsedResponse);
        } catch (e) {
          print('JSON parsing error: $e');
          print('Raw response: $generatedText');
          return null;
        }
      } else {
        print('Gemini API Error: ${response.statusCode} - ${response.body}');
        return null;
      }
    } catch (e) {
      print('Exception calling Gemini API: $e');
      return null;
    }
  }

  /// Clean response text by removing markdown code blocks
  static String _cleanResponseText(String text) {
    String cleaned = text.replaceAll(RegExp(r'```json\s*'), '');
    cleaned = cleaned.replaceAll(RegExp(r'```\s*'), '');
    return cleaned.trim();
  }

  /// Get detailed product info from barcode (additional method)
  static Future<Map<String, dynamic>?> getDetailedProductInfo(
      String barcode) async {
    try {
      final url = '$openFoodFactsBaseUrl/$barcode.json';
      final response = await http.get(
        Uri.parse(url),
        headers: {'User-Agent': 'Flutter-App/1.0'},
      ).timeout(Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == 1) {
          final product = data['product'];
          return {
            'product_name': product['product_name'] ?? 'Unknown Product',
            'ingredients_text': product['ingredients_text'] ?? '',
            'nutrition_grades': product['nutrition_grades'] ?? '',
            'brands': product['brands'] ?? '',
            'categories': product['categories'] ?? '',
            'image_url': product['image_front_url'] ?? '',
            'barcode': barcode,
          };
        }
      }
      return null;
    } catch (e) {
      print('Error getting detailed product info: $e');
      return null;
    }
  }
}

/// Model class for barcode product data
class BarcodeProduct {
  final String productName;
  final String ingredientsText;
  final List<String> ingredients;
  final String barcode;

  BarcodeProduct({
    required this.productName,
    required this.ingredientsText,
    required this.ingredients,
    required this.barcode,
  });

  @override
  String toString() {
    return 'BarcodeProduct(name: $productName, ingredients: ${ingredients.length} items, barcode: $barcode)';
  }
}

/// Gemini response model (reusing from previous artifact)
class GeminiResponse {
  final String productName;
  final int tscore;
  final String riskLevel;
  final List<BadIngredient> badIngredients;

  GeminiResponse({
    required this.productName,
    required this.tscore,
    required this.riskLevel,
    required this.badIngredients,
  });

  factory GeminiResponse.fromJson(Map<String, dynamic> json) {
    return GeminiResponse(
      productName: json['productName'] ?? 'Unknown Product',
      tscore: json['tscore'] ?? 0,
      riskLevel: json['riskLevel'] ?? 'Unknown',
      badIngredients: (json['badIngredients'] as List<dynamic>?)
              ?.map((item) => BadIngredient.fromJson(item))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'productName': productName,
      'tscore': tscore,
      'riskLevel': riskLevel,
      'badIngredients': badIngredients.map((e) => e.toJson()).toList(),
    };
  }

  @override
  String toString() {
    return 'GeminiResponse(productName: $productName, tscore: $tscore, riskLevel: $riskLevel, badIngredients: ${badIngredients.length} items)';
  }
}

class BadIngredient {
  final String name;
  final String category;
  final int penalty;

  BadIngredient({
    required this.name,
    required this.category,
    required this.penalty,
  });

  factory BadIngredient.fromJson(Map<String, dynamic> json) {
    return BadIngredient(
      name: json['name'] ?? '',
      category: json['category'] ?? '',
      penalty: json['penalty'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'category': category,
      'penalty': penalty,
    };
  }

  @override
  String toString() {
    return 'BadIngredient(name: $name, category: $category, penalty: $penalty)';
  }
}

// Example usage:
/*
void main() async {
  // Method 1: Just get ingredients from barcode
  final product = await BarcodeAnalysisService.extractIngredientsFromBarcode('3017624010701');
  if (product != null) {
    print('Product: ${product.productName}');
    print('Ingredients: ${product.ingredients}');
  }

  // Method 2: Full analysis with Gemini AI
  final analysis = await BarcodeAnalysisService.analyzeProductFromBarcode('3017624010701');
  if (analysis != null) {
    print('Product: ${analysis.productName}');
    print('T-Score: ${analysis.tscore}');
    print('Risk Level: ${analysis.riskLevel}');
    
    for (var ingredient in analysis.badIngredients) {
      print('Bad ingredient: ${ingredient.name} (${ingredient.category}) - Penalty: ${ingredient.penalty}');
    }
  }

  // Method 3: Get detailed product info
  final details = await BarcodeAnalysisService.getDetailedProductInfo('3017624010701');
  if (details != null) {
    print('Detailed info: $details');
  }
}
*/
