import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GeminiApiService {
  static const String apiKey =
      'YOUR_GEMINI_API_KEY'; // Replace with your actual API key
  static const String baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

  /// Analyze image using Gemini API and return structured response
  static Future<GeminiResponse?> analyzeImage(String imagePath,
      {String? customPrompt}) async {
    try {
      // Read image file and convert to base64
      final imageFile = File(imagePath);
      final imageBytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(imageBytes);

      // Determine MIME type based on file extension
      String mimeType = _getMimeType(imagePath);

      // Default prompt for ingredient analysis
      final prompt = customPrompt ??
          '''
      Analyze this product image and provide a response in the following JSON format:
      {
        "productName": "detected product name",
        "tscore":  numerical_score_0_to_100 testosterone level of the food or ingredients,
        "riskLevel": "Low Risk/Medium Risk/High Risk",
        "badIngredients": [
          {
            "name": "ingredient_name",
            "category": "Lifestyle Risk/Health Risk/Allergen",
            "penalty": numerical_penalty
          }
        ]
      }
      
      Analyze the ingredients visible in the image and assess their health impact. Return only valid JSON.
      ''';

      // Prepare request body
      final requestBody = {
        "contents": [
          {
            "parts": [
              {"text": prompt},
              {
                "inline_data": {"mime_type": mimeType, "data": base64Image}
              }
            ]
          }
        ],
        "generationConfig": {
          "temperature": 0.4,
          "topK": 32,
          "topP": 1,
          "maxOutputTokens": 4096,
        }
      };

      // Make the API request
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': apiKey,
        },
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        // Extract the text from Gemini's response
        final generatedText =
            responseData['candidates'][0]['content']['parts'][0]['text'];

        // Clean the response text (remove markdown code blocks if present)
        final cleanedText = _cleanResponseText(generatedText);

        // Parse the generated text as JSON
        try {
          final parsedResponse = jsonDecode(cleanedText);
          return GeminiResponse.fromJson(parsedResponse);
        } catch (e) {
          print('JSON parsing error: $e');
          print('Raw response: $generatedText');
          return null;
        }
      } else {
        print('API Error: ${response.statusCode} - ${response.body}');
        return null;
      }
    } catch (e) {
      print('Exception occurred: $e');
      return null;
    }
  }

  /// Analyze image from bytes instead of file path
  static Future<GeminiResponse?> analyzeImageFromBytes(
      List<int> imageBytes, String mimeType,
      {String? customPrompt}) async {
    try {
      final base64Image = base64Encode(imageBytes);

      final prompt = customPrompt ??
          '''
      Analyze this product image and provide a response in the following JSON format:
      {
        "productName": "detected product name",
        "tscore": numerical_score_0_to_100 testosterone level of the food or ingredients,
        "riskLevel": "Low Risk/Medium Risk/High Risk",
        "badIngredients": [
          {
            "name": "ingredient_name",
            "category": "Lifestyle Risk/Health Risk/Allergen",
            "penalty": numerical_penalty
          }
        ]
      }
      
      Analyze the ingredients visible in the image and assess their health impact. Return only valid JSON.
      ''';

      final requestBody = {
        "contents": [
          {
            "parts": [
              {"text": prompt},
              {
                "inline_data": {"mime_type": mimeType, "data": base64Image}
              }
            ]
          }
        ],
        "generationConfig": {
          "temperature": 0.4,
          "topK": 32,
          "topP": 1,
          "maxOutputTokens": 4096,
        }
      };

      final response = await http.post(
        Uri.parse(baseUrl),
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': apiKey,
        },
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final generatedText =
            responseData['candidates'][0]['content']['parts'][0]['text'];
        final cleanedText = _cleanResponseText(generatedText);

        try {
          final parsedResponse = jsonDecode(cleanedText);
          return GeminiResponse.fromJson(parsedResponse);
        } catch (e) {
          print('JSON parsing error: $e');
          return null;
        }
      } else {
        print('API Error: ${response.statusCode} - ${response.body}');
        return null;
      }
    } catch (e) {
      print('Exception occurred: $e');
      return null;
    }
  }

  /// Get MIME type based on file extension
  static String _getMimeType(String filePath) {
    final extension = filePath.toLowerCase().split('.').last;
    switch (extension) {
      case 'png':
        return 'image/png';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  /// Clean response text by removing markdown code blocks
  static String _cleanResponseText(String text) {
    // Remove markdown code blocks (```json ... ```)
    String cleaned = text.replaceAll(RegExp(r'```json\s*'), '');
    cleaned = cleaned.replaceAll(RegExp(r'```\s*'), '');

    // Trim whitespace
    cleaned = cleaned.trim();

    return cleaned;
  }
}

class GeminiResponse {
  final String productName;
  final int tscore;
  final String riskLevel;
  final List<BadIngredient> badIngredients;

  GeminiResponse({
    required this.productName,
    required this.tscore,
    required this.riskLevel,
    required this.badIngredients,
  });

  factory GeminiResponse.fromJson(Map<String, dynamic> json) {
    return GeminiResponse(
      productName: json['productName'] ?? 'Unknown Product',
      tscore: json['tscore'] ?? 0,
      riskLevel: json['riskLevel'] ?? 'Unknown',
      badIngredients: (json['badIngredients'] as List<dynamic>?)
              ?.map((item) => BadIngredient.fromJson(item))
              .toList() ??
          [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'productName': productName,
      'tscore': tscore,
      'riskLevel': riskLevel,
      'badIngredients': badIngredients.map((e) => e.toJson()).toList(),
    };
  }

  @override
  String toString() {
    return 'GeminiResponse(productName: $productName, tscore: $tscore, riskLevel: $riskLevel, badIngredients: ${badIngredients.length} items)';
  }
}

class BadIngredient {
  final String name;
  final String category;
  final int penalty;

  BadIngredient({
    required this.name,
    required this.category,
    required this.penalty,
  });

  factory BadIngredient.fromJson(Map<String, dynamic> json) {
    return BadIngredient(
      name: json['name'] ?? '',
      category: json['category'] ?? '',
      penalty: json['penalty'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'category': category,
      'penalty': penalty,
    };
  }

  @override
  String toString() {
    return 'BadIngredient(name: $name, category: $category, penalty: $penalty)';
  }
}

// Example usage:
/*
void main() async {
  // Using file path
  final response = await GeminiApiService.analyzeImage('/path/to/image.jpg');
  if (response != null) {
    print('Product: ${response.productName}');
    print('Score: ${response.tscore}');
    print('Risk: ${response.riskLevel}');
    for (var ingredient in response.badIngredients) {
      print('Bad ingredient: ${ingredient.name} (${ingredient.penalty})');
    }
  }

  // Using image bytes
  final file = File('/path/to/image.jpg');
  final bytes = await file.readAsBytes();
  final response2 = await GeminiApiService.analyzeImageFromBytes(
    bytes, 
    'image/jpeg'
  );
}
*/
