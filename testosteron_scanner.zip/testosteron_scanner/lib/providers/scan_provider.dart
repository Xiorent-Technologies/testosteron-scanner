import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/scan_result.dart';
import 'barcode.dart';
import 'gemini.dart';

enum ScanState { initial, loading, success, error }

class ScanProvider with ChangeNotifier {
  ScanState _state = ScanState.initial;
  ScanResult? _scanResult;
  String _errorMessage = '';
  String baseUrl = 'http://10.0.2.2:8000';

  ScanState get state => _state;
  ScanResult? get scanResult => _scanResult;
  String get errorMessage => _errorMessage;

  void _setState(ScanState state) {
    _state = state;
    notifyListeners();
  }

  Future<void> scanBarcode(String barcode) async {
    _setState(ScanState.loading);

    try {
      final product =
          await BarcodeAnalysisService.analyzeProductFromBarcode(barcode);
      // final response = await http.post(
      //   Uri.parse('$baseUrl/scan/barcode'),
      //   headers: {'Content-Type': 'application/json'},
      //   body: json.encode({'barcode': barcode}),
      // );

      // if (response.statusCode == 200) {
      //   final data = json.decode(response.body);
      //   _scanResult = ScanResult.fromJson(data);
      //   _setState(ScanState.success);
      // }
      //
      if (product != null) {
        _scanResult = ScanResult.fromJson(product.toJson());
        _setState(ScanState.success);
      } else {
        _errorMessage = 'Failed to scan barcode:';

        _setState(ScanState.error);
      }
    } catch (e) {
      _errorMessage = 'Error scanning barcode: $e';
      _setState(ScanState.error);
    }
  }

  Future<void> scanImage(String imagePath) async {
    _setState(ScanState.loading);

    try {
      final response = await GeminiApiService.analyzeImage(imagePath);
      // var request = http.MultipartRequest(
      //   'POST',
      //   Uri.parse('$baseUrl/scan/image'),
      // );

      // request.files.add(await http.MultipartFile.fromPath(
      //   'image',
      //   imagePath,
      // ));

      // var streamedResponse = await request.send();
      // var response = await http.Response.fromStream(streamedResponse);

      // if (response.statusCode == 200) {
      //   final data = json.decode(response.body);
      //   _scanResult = ScanResult.fromJson(data);
      //   _setState(ScanState.success);
      // } else {
      //   _errorMessage = 'Failed to scan image: ${response.statusCode}';
      //   _setState(ScanState.error);
      // }
      if (response != null) {
        _scanResult = ScanResult.fromJson(response.toJson());
        _setState(ScanState.success);
      }
    } catch (e) {
      _errorMessage = 'Error scanning image: $e';
      _setState(ScanState.error);
    }
  }

  void reset() {
    _state = ScanState.initial;
    _scanResult = null;
    _errorMessage = '';
    notifyListeners();
  }
}
