class ScanResult {
  final String productName;
  final int tscore;
  final String riskLevel;
  final List<BadIngredient> badIngredients;

  ScanResult({
    required this.productName,
    required this.tscore,
    required this.riskLevel,
    required this.badIngredients,
  });

  factory ScanResult.fromJson(Map<String, dynamic> json) {
    return ScanResult(
      productName: json['productName'] ?? 'Unknown Product',
      tscore: json['tscore'] ?? 0,
      riskLevel: json['riskLevel'] ?? 'Unknown Risk',
      badIngredients: (json['badIngredients'] as List<dynamic>?)
              ?.map((ingredient) => BadIngredient.fromJson(ingredient))
              .toList() ??
          [],
    );
  }
}

class BadIngredient {
  final String name;
  final String category;
  final int penalty;

  BadIngredient({
    required this.name,
    required this.category,
    required this.penalty,
  });

  factory BadIngredient.fromJson(Map<String, dynamic> json) {
    return BadIngredient(
      name: json['name'] ?? 'Unknown Ingredient',
      category: json['category'] ?? 'Unknown Category',
      penalty: json['penalty'] ?? 0,
    );
  }
}