package com.example.testosteron_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
